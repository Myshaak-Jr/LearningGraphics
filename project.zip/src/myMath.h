#pragma once

#include <glm/glm.hpp>

namespace myMath {
	uint32_t hashPos(glm::ivec2 pos, uint32_t seed);
}