#pragma once

#include <glm/glm.hpp>


namespace comps {
	struct transform {
		glm::mat4 matrix;
	};
}