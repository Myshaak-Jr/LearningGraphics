#pragma once

#include <glm/glm.hpp>


namespace comps {
	struct position {
		glm::vec3 pos;
	};
}