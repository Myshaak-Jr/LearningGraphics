#pragma once

namespace comps {
	namespace terrain {
		struct root {};
		struct chunk {};
	}
}