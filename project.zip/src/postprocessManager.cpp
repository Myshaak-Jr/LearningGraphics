#include "postprocessManager.h"

#include <iostream>
#include <vector>
#include <algorithm>

#include "programManager.h"


void PostprocessManager::createTexture(GLuint& texture, int w, int h, GLenum format, GLenum type) {
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	glTexImage2D(GL_TEXTURE_2D, 0, format, w, h, 0, format, type, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

void PostprocessManager::initFramebuffer(int width, int height) {
	glGenFramebuffers(1, &fbo);
	glBindFramebuffer(GL_FRAMEBUFFER, fbo);

	glViewport(0, 0, width, height);
	
	// Create textures
	createTexture(colorTexture, width, height, GL_RGB, GL_UNSIGNED_BYTE);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, colorTexture, 0);
	createTexture(normalTexture, width, height, GL_RGB, GL_UNSIGNED_BYTE);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, normalTexture, 0);
	createTexture(depthTexture, width, height, GL_DEPTH_COMPONENT, GL_FLOAT);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depthTexture, 0);

	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
		std::cout << "ERROR::FRAMEBUFFER:: Framebuffer is not complete!" << std::endl;

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void PostprocessManager::initVAO() {
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	const float vertices[4 * 3 + 4 * 2] = {
		// vertex positions
		-1.0f, +1.0f,
		-1.0f, -1.0f,
		+1.0f, -1.0f,
		+1.0f, +1.0f,

		// texture positions
		0.0f, 1.0f,
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
	};

	const uint16_t indices[6] = {
		0, 1, 2,
		0, 2, 3,
	};

	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)(sizeof(vertices) / 2));

	glGenBuffers(1, &ebo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glBindVertexArray(0);
}

void PostprocessManager::initProgram(int width, int height, const std::string& vertex, const std::string& fragment) {
	std::vector<GLuint> compiledShaders;
	
	compiledShaders.push_back(ProgramManager::CreateShader(GL_VERTEX_SHADER, vertex.c_str()));
	compiledShaders.push_back(ProgramManager::CreateShader(GL_FRAGMENT_SHADER, fragment.c_str()));

	shaderProgram = ProgramManager::CreateProgram(compiledShaders);

	std::for_each(compiledShaders.begin(), compiledShaders.end(), glDeleteShader);

	colorTextureLoc = glGetUniformLocation(shaderProgram, "colorTexture");
	normalTextureLoc = glGetUniformLocation(shaderProgram, "normalTexture");
	depthTextureLoc = glGetUniformLocation(shaderProgram, "depthTexture");
	resolutionLoc = glGetUniformLocation(shaderProgram, "resolution");

	glUseProgram(shaderProgram);
	glUniform2f(resolutionLoc, static_cast<float>(width), static_cast<float>(height));
	glUniform1i(colorTextureLoc, 0);
	glUniform1i(normalTextureLoc, 1);
	glUniform1i(depthTextureLoc, 2);
	glUseProgram(0);
}

PostprocessManager::PostprocessManager(int width, int height, const std::string& vertex, const std::string& fragment) {
	initFramebuffer(width, height);
	initVAO();
	initProgram(width, height, vertex, fragment);
}

PostprocessManager::~PostprocessManager() {
	glDeleteVertexArrays(1, &vao);
	glDeleteBuffers(1, &vbo);
	glDeleteBuffers(1, &ebo);
	glDeleteFramebuffers(1, &fbo);
	glDeleteTextures(1, &colorTexture);
	glDeleteTextures(1, &normalTexture);
	glDeleteTextures(1, &depthTexture);
}

void PostprocessManager::Resize(int width, int height) {
	glBindTexture(GL_TEXTURE_2D, colorTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);

	glBindTexture(GL_TEXTURE_2D, normalTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);

	glBindTexture(GL_TEXTURE_2D, depthTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, width, height, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);

	glUseProgram(shaderProgram);
	glUniform2f(resolutionLoc, static_cast<float>(width), static_cast<float>(height));
	glUseProgram(0);

	glBindFramebuffer(GL_FRAMEBUFFER, fbo);
	glViewport(0, 0, width, height);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void PostprocessManager::BeforeRender(myColor::RGB bgColor) {
	glBindFramebuffer(GL_FRAMEBUFFER, fbo);
	glClearColor(bgColor.r, bgColor.g, bgColor.b, 1.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void PostprocessManager::AfterRender() {
	GLenum err;
	while ((err = glGetError()) != GL_NO_ERROR);

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cerr << "OpenGL error (during binding framebuffer): " << err << std::endl;
	}

	glUseProgram(shaderProgram);
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cerr << "OpenGL error (during binding postprocess shader): " << err << std::endl;
	}

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, colorTexture);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, normalTexture);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, depthTexture);
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cerr << "OpenGL error (during binding postprocess textures): " << err << std::endl;
	}

	glBindVertexArray(vao);
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cerr << "OpenGL error (during binding postprocess VAO): " << err << std::endl;
	}

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, 0);
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cerr << "OpenGL error (during postprocess render): " << err << std::endl;
	}

	glBindVertexArray(0);
	glUseProgram(0);
}
